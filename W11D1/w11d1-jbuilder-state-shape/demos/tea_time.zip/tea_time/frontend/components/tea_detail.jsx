import React from 'react';

class TeaDetail extends React.Component {

  render() {
    return (
      <div className="tea-detail">
        Detail goes here
      </div>
    );
  }
}

export default TeaDetail;