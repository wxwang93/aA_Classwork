import React from 'react';
// import TeaIndex from './tea_index'; // WRONG, import container
import TeaIndexContainer from './tea_index_container';

const App = (props) => {
  return (
    <TeaIndexContainer />
  );
}

export default App;