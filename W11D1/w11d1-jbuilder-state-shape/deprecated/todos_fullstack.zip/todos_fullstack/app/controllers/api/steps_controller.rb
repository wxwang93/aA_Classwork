class Api::StepsController < Api::ApiController
  def create
    @step = Step.new(step_params)

    if @step.save
      render :show
    else
      render json: @step.errors.full_messages, status: 422
    end
  end

  def index
    if params[:todo_id]
      @steps = Todo.find(params[:todo_id]).steps
    else
      @steps = Step.all
    end
    render :index
  end

  def destroy
    @step = Step.find(params[:id]).destroy 
    render :show
  end

  def update
    @step = Step.find(params[:id])
    if @step
      @step.update(step_params)
      render :show
    else
      render json: { message: 'not found', status: 404 }
    end
  end

  private
  def step_params
    params.require(:step).permit(:title, :done, :body, :todo_id)
  end
end
