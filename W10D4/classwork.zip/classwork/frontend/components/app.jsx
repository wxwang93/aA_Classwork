import React from 'react';

const App = () => {
    return (
        <h1>This is the App Component</h1>
    )
}

export default App;